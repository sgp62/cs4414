g++ -g -Wall -Wpedantic -std=c++17 farmville.cpp displayobject.cpp -o farmville
