g++ -O3 -Wall -Wpedantic -std=c++17 main.cpp bignum.cpp -pg -o bignum 
